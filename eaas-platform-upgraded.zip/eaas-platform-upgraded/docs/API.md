# API Documentation (Placeholder)

This document will describe all REST and blockchain API endpoints. For now, refer to the source code in `backend/src/` for example routes and request/response shapes.
