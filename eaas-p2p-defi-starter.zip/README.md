# DeFi-Enabled P2P Energy-as-a-Service (EaaS) Platform

This is a simplified scaffold for a DeFi-enabled, AI-powered P2P Energy trading platform.
It includes smart contracts, a backend API, a React frontend, and an AI microservice.
